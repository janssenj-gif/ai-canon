#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv
.venv/bin/pip install -q -r requirements.txt
PYTHONPATH=src .venv/bin/python -m canon.release --verify --version pilot-v0.1
echo 'If the line above says MATCH, you rebuilt the release exactly.'
